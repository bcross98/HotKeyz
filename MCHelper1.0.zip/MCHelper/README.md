# MCScript

TO RUN:
1.) Get python 3 - https://www.python.org/downloads/
    1a.) Restart your pc if you can't type in the following commands
2.) Get pyautogui - in cmd type: pip install pyautogui
3.) Get keyboard - in cmd type: pip install keyboard
4.) Restart your pc

#Where I left off:
-Automate switching iron picks
-Add separate function for if you have a mining speed bonus